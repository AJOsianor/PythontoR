# python
# Import necessary libraries
import random

# Define the variables to generate a list of workers dynamically
num_workers = 400
workers = []

# Generate the list of workers with random salaries
for i in range(num_workers):
    worker = {
        'name': f'Worker_{i+1}',
        'salary': random.randint(5000, 35000),
        'gender': random.choice(['Male', 'Female'])
    }
    workers.append(worker)

# Function to assign the Employee level based on salary and gender
def assign_employee_level(salary, gender):
    if salary > 10000 and salary < 20000:
        return "A1"
    elif salary > 7500 and salary < 30000 and gender == 'Female':
        return "A5-F"
    else:
        return "Not classified"

# Generate payment slips and assign Employee levels using the for loop
for worker in workers:
    try:
        salary = worker['salary']
        gender = worker['gender']
        employee_level = assign_employee_level(salary, gender)
        print(f"{worker['name']} - Salary: ${salary} - Employee Level: {employee_level}")
    except Exception as e:
        print(f"Error processing {worker['name']}: {e}")



